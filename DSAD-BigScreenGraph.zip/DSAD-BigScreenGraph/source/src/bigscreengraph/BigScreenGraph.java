/**
 * @author Malu(2018AB04154), Sanjib(2018AB04153), Pradeep(2018AB04152)
 */
package bigscreengraph;

public class BigScreenGraph {

    public static void main(String[] args) {

        try {
        	System.out.println("**** Big Screen Graph ****");

            MenuOptions choice;
            InputHelper helper = new InputHelper();

            // Ensure file is loaded before menu options are displayed.
            //helper.LoadInitialActorMovieFile();
            helper.ReadActorMovieFile("input/test.txt");
            System.out.println("Loading the default file input/text.txt.");
            
            do {
                helper.ShowMenu();
                choice = helper.ReadMenuOption();

                helper.Do(choice);
            } while (choice != MenuOptions.Exit);

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
        }
    }

}
