/**
 * @author Malu(2018AB04154), Sanjib(2018AB04153), Pradeep(2018AB04152)
 */
package bigscreengraph.DataStructures;

public class Node<T> {

    public T data;
    public Node<T> next = null;
    public Node<T> prev = null;

    public Node(T data) {
        this.data = data;
    }
}