/**
 * @author Malu(2018AB04154), Sanjib(2018AB04153), Pradeep(2018AB04152)
 */
package bigscreengraph;

/**
 * Type of vertices in the graph.
 * ACTOR - for actor node
 * MOVIE - for movie node
 */
public enum VertexType {
    ACTOR(1,"ACTOR",9999),
    MOVIE(2,"MOVIE",2);

    public int value;
    public String name;
    public int maxEdgeLimit;
    
    private VertexType(int value, String name, int maxEdgeLimit) {
        this.value = value;
        this.name = name;
        this.maxEdgeLimit = maxEdgeLimit;
    }

    public static VertexType ToEnum(int id) {
        for (VertexType type : values()) {
            if (type.value == id) {
                return type;
            }
        }
        return null;
    }

}
