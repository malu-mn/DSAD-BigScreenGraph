/**
 * @author Malu(2018AB04154), Sanjib(2018AB04153), Pradeep(2018AB04152)
 */
package bigscreengraph.Graph;

import java.util.LinkedList;

public class AdjacencyList {

    private Vertex head;
    private LinkedList<Vertex> adjacentVertices;

    // ctor
    public AdjacencyList(Vertex head) {
        this.head = head;
        this.adjacentVertices = new LinkedList<>();
    }

    public void AddEdgeTo(Vertex v) {
        this.adjacentVertices.add(v);
    }

    public int EdgeCount() {
        return adjacentVertices.size();
    }

    public Vertex getHeadVertex() {
        return head;
    }

    public LinkedList<Vertex> getAdjacentVertices() {
        return this.adjacentVertices;
    }
}