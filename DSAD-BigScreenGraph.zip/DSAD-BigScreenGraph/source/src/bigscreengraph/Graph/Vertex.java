/**
 * @author Malu(2018AB04154), Sanjib(2018AB04153), Pradeep(2018AB04152)
 */
package bigscreengraph.Graph;

public class Vertex {

    private String name;
    private String type;
    private boolean visited;
    public int edgeLimit;
    
    // ctor
    public Vertex(String name, String type, int limit) {
        this.name = name;
        this.type = type;
        this.edgeLimit = limit;
        this.visited = false;
    }

    public String toString() {
        return name + " (" + type + ")";
    }

    public String getName() {
        return this.name;
    }

    public String getType() {
        return this.type;
    }

    public boolean isVisited() {
        return this.visited;
    }

    public void setVisited(boolean value) {
        this.visited = value;
    }
}