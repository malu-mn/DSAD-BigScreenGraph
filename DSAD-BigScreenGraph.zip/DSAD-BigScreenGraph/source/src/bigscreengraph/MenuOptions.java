/**
 * @author Malu(2018AB04154), Sanjib(2018AB04153), Pradeep(2018AB04152)
 */
package bigscreengraph;

/**
 * Menu options enumeration used for interacting with the user to operate
 * on the graph.
 */
public enum MenuOptions {
    LoadMovieFile (1, "Load a different movie data file."),
    DisplayMoviesAndActors (2, "List Movies and Actors."),
    DisplayMovies (3, "List Movies."),
    DisplayActors (4, "List Actors."),
    DisplayMoviesOfActor (5, "Show Movies of an Actor."),
    DisplayActorsOfMovie (6, "Show Actors in a Movie."),
    FindMovieRelation (7, "Find if two movies are related R(A,B)."),
    FindMovieTransitiveRelation (8, "Find if two movies are connected T(A,B) via another movie C."),
    Exit (9,"Exit");
    
    public int value;
    public String name;
    
    private MenuOptions(int value, String name) {
        this.value = value;
        this.name = name;
    }

    public static MenuOptions ToEnum(int id) {
        for (MenuOptions type : values()) {
            if (type.value == id) {
                return type;
            }
        }
        return null;
    }
}