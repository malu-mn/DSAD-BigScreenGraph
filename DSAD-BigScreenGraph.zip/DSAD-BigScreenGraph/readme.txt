To run the program using the following command from the command line from within the 'ExecutableJar' folder:

java -jar BigScreenGraph.jar


Assignment Group:
1. Pamidi Pradeep Kumar (2018AB04152) 
2. Sanjib Panigrahi (2018AB04153)
3. Malu (2018AB04154)